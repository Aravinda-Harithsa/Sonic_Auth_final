# Eysip2020-12-boot-DSP_Audio
## Aravinda Harithsa's Github Branch 

### DSP Bootcamp Module  : 

- Module 1 : Signal statistics and noise
- Module 2 : Quantization and sampling
- Module 3 : Linear systems
- Module 4 : Convolution  
- Module 5 : Fourier transforms 
- Module 6 : Complex Numbers 
- Module 7 : Complex Fourier transform
- Module 8 : Fast fourier Transform
- Module 9 : Digital filter design
- Module 10 : FIR filters
- Module 11 : IIR filters  
- Module 12 : Window Filters 
- Module 13 : Coustom Filters 
- Module 14 : Match Filters 
- Module 15 : Interpolation
- Module 18 : Waveform generation  
- Python Exp 1 : Audio Synthesizer 
- Python Exp 2 : Spectrum Analyzer 

