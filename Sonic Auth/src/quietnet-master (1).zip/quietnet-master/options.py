rate = 44100
freq = 19100# chosen because it is outside most people's hearing and worked for my microphone and speakers
channels = 1
frame_length = 3
chunk = 256
datasize = chunk * frame_length
sigil = "00"
